# Carta
Say hello to Carta, a modern, illustrated site template.

[eatapapaya.com](https://www.eatapapaya.com)
[@jrdnbwmn](https://www.twitter.com/jrdnbwmn)

Demo images from [Unsplash](https://unsplash.com/).
Icons from [Entypo](http://entypo.com/).

## Files
The plain HTML and CSS files are in the main directory.

For the Gulp/Sass development setup, use the files in `dev` and the instructions for [Pear](https://github.com/jrdnbwmn/Pear).